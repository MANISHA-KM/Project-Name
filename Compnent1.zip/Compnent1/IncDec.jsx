import React, {useEffect, useState} from 'react'
const IncDec=()=>{
    let [count,setcount]=useState(0)
    let inc=()=>{
        setcount(count+1)
    }
    let dec=()=>{
        setcount(count-1)
    }
    useEffect(()=>(
        alert("click")
    ))
    return(
        <div>
            <>
            <h1>count: {count}</h1>
            <button onClick={inc}>Inc</button>
            <button onClick={dec}>Dec</button>
            </>
        </div>
    )
}
export  default IncDec