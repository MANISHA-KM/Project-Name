let Cdata1=[
    {
        imgs:"https://th.bing.com/th/id/OIP.w0elQDf1zxHrYm28jcBvAwHaEK?rs=1&pid=ImgDetMain",
        tittle:"car",
        Watch :"https://www.bing.com/ck/a?!&&p=e92fb8d949233e78JmltdHM9MTcxODIzNjgwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI0Mw&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=top+10+bollywood+movies&u=a1aHR0cHM6Ly93d3cuaW1kYi5jb20vbGlzdC9sczA1MTU5NDQ5Ni8&ntb=1",
        Aname:"BMW"
    },
    {
        imgs:"https://cdni.autocarindia.com/Utils/ImageResizer.ashx?n=http:%2f%2fcdni.autocarindia.com%2fReviews%2f2020-Mahindra-Thar-front-static.jpg&c=0",
        title:"THAR",
        Watch :"https://www.cardekho.com/mahindra/thar",
        Aname:"THAR"
    },
    {
        imgs:"https://images.news18.com/ibnkhabar/uploads/2022/07/thar-1-1.jpg",
        title:"THAR",
        Wacth :"https://www.bing.com/ck/a?!&&p=e92fb8d949233e78JmltdHM9MTcxODIzNjgwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI0Mw&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=top+10+bollywood+movies&u=a1aHR0cHM6Ly93d3cuaW1kYi5jb20vbGlzdC9sczA1MTU5NDQ5Ni8&ntb=1",
        Aname:"THAR"
    },
]

export default Cdata1