import React from 'react'

const Car1=(props)=>{
    return(
        <div className="Top">
            <div className="Maincard">
                <div className="Card">
                    <div className="imgs">
                        <img className="img" src={props.imgs} alt="error"></img>
                    </div>
                    <div className="Cdata">
                        <h4>{props.title}</h4>
                        <a href={props.watch}>
                            <button className="btn">Watch</button>
                        </a>
                    <div className="actor">
                            <h4>{props.Aname}</h4>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Car1